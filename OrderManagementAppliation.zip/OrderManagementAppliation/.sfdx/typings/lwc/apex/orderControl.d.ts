declare module "@salesforce/apex/orderControl.addOrder" {
  export default function addOrder(param: {quan: any, prod: any, price: any}): Promise<any>;
}
declare module "@salesforce/apex/orderControl.getalldata" {
  export default function getalldata(): Promise<any>;
}
declare module "@salesforce/apex/orderControl.getonedata" {
  export default function getonedata(param: {x: any}): Promise<any>;
}
declare module "@salesforce/apex/orderControl.getallodata" {
  export default function getallodata(): Promise<any>;
}
declare module "@salesforce/apex/orderControl.del" {
  export default function del(param: {a: any}): Promise<any>;
}
declare module "@salesforce/apex/orderControl.submitForApproval" {
  export default function submitForApproval(param: {o: any}): Promise<any>;
}
declare module "@salesforce/apex/orderControl.getOrderList" {
  export default function getOrderList(param: {searchKey: any}): Promise<any>;
}
declare module "@salesforce/apex/orderControl.getpb" {
  export default function getpb(): Promise<any>;
}
declare module "@salesforce/apex/orderControl.getOrdermList" {
  export default function getOrdermList(param: {searchey: any}): Promise<any>;
}
declare module "@salesforce/apex/orderControl.getOrder1List" {
  export default function getOrder1List(param: {searchst: any}): Promise<any>;
}

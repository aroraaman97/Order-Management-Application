import { LightningElement, track } from 'lwc';
import { createRecord } from 'lightning/uiRecordApi';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import ORDEROBJECT from '@salesforce/schema/Order';
import AccountName  from '@salesforce/schema/Order.AccountId';
import Status from '@salesforce/schema/Order.Status';
import OrderStartDate from '@salesforce/schema/Order.EffectiveDate';
import ContractNumber from '@salesforce/schema/Order.ContractId';
import ShippingAddress from '@salesforce/schema/Order.ShippingAddress';
import CompanyAuthorisedBy from '@salesforce/schema/Order.CompanyAuthorizedById';
import CustomerAuthorisedBy from '@salesforce/schema/Order.CustomerAuthorizedById';
import BillingAddress from '@salesforce/schema/Order.BillingAddress';

export default class CreateOrder extends LightningElement {
   
    orderObject = ORDEROBJECT;
    
    myFields = [AccountName,Status,OrderStartDate,ContractNumber,ShippingAddress,CompanyAuthorisedBy,CustomerAuthorisedBy,BillingAddress];

   CreateOrder(){}

}
import { LightningElement,api } from 'lwc';
import ORDEROBJECT from '@salesforce/schema/Order';
import AccountName  from '@salesforce/schema/Order.AccountId';
import Status from '@salesforce/schema/Order.Status';
import OrderStartDate from '@salesforce/schema/Order.EffectiveDate';
import ContractNumber from '@salesforce/schema/Order.ContractId';
import ShippingAddress from '@salesforce/schema/Order.ShippingAddress';
import CompanyAuthorisedBy from '@salesforce/schema/Order.CompanyAuthorizedById';
import CustomerAuthorisedBy from '@salesforce/schema/Order.CustomerAuthorizedById';
import BillingAddress from '@salesforce/schema/Order.BillingAddress';
export default class EditOrder extends LightningElement {
    @api recordId;
    @api objectApiName=ORDEROBJECT;

    fields = [AccountName,Status,OrderStartDate,ContractNumber,ShippingAddress,CompanyAuthorisedBy,CustomerAuthorisedBy,BillingAddress];
}
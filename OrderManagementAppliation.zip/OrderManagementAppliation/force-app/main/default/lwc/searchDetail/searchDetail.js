import { LightningElement,track,api } from 'lwc';
import getData from '@salesforce/apex/orderControl.getalldata'
import ORDER_OBJECT from '@salesforce/schema/OrderItem';
import a from '@salesforce/schema/OrderItem.Quantity';
import b from '@salesforce/schema/PricebookEntry.Product2Id';
import c from '@salesforce/schema/PricebookEntry.UnitPrice';
//import d from '@salesforce/schema/PricebookEntry.ProductName';
import PBID_FIELD from '@salesforce/schema/OrderItem.PricebookEntryId';
import getOrderList from '@salesforce/apex/orderControl.getOrderList';
import getOrder1List from '@salesforce/apex/orderControl.getOrder1List';
import saveData from '@salesforce/apex/orderControl.addOrder';
// import standard toast event 
import {ShowToastEvent} from 'lightning/platformShowToastEvent'

export default class SearchDetail extends LightningElement {
    @api OrderId
    @api pricebookId
    @track order   
    ind
    id
    up
    search = '';
    search1 = '';
    open
    pro
    qua
    uni
    ab=a;
    orderObject = ORDER_OBJECT;
    myFields = [a,b,c,PBID_FIELD];
 
    // update search var when input field value change
    edit(event)
    {
        this.ind=event.target.value;
      //  alert(this.ind);
        this.open=true;
        
       this.id=this.order[this.ind].Id;
       this.up=this.order[this.ind].UnitPrice;
       alert(this.id+" "+this.up);
        
     
    }
    clear(event){
        this.search='';
        this.order=null;
    }
    idChange(event){
        this.pro=event.target.value
    }
    nameChange(event){
        this.qua=event.target.value
    }
    salChange(event){
        this.uni=event.target.value
    }
    save(event){
        
    alert(this.pro+" "+this.qua+" "+this.uni);
    this.s={'prod':this.pro,'quan':this.qua,'price':this.uni}
    saveData(this.s);
    location.reload();
   
    }
    close()
    {
        this.open=false;
    }

    updateSearchKey(event) {
        this.search = event.target.value;
        //alert("this is search"+this.search);
        
    }
    updateSearch(event) {
        
        this.search1=event.target.value;
        alert(this.search1);
    }
 
    // call apex method on button click 
    handleSearch() {
        this.on=true;
        // if search input value is not blank then call apex method, else display error msg 
        if (this.search !== '') {
           
           //` alert("this is search"+this.search);
            getOrderList({
                    searchKey: this.search
                })
                .then(result => {
                    // set @track contacts variable with return contact list from server  
                    this.order = result;
                })
                .catch(error => {
                    // display server exception in toast msg 
                    const event = new ShowToastEvent({
                        title: 'Error',
                        variant: 'error',
                        message: error.body.message,
                    });
                    this.dispatchEvent(event);
                    // reset contacts var with null   
                    this.order = null;
                });
        }
        else if (this.search1 !== '') {
            alert(this.search1);
            getOrder1List({
                    searchst: this.search1
                })
                .then(result => {
                    // set @track contacts variable with return contact list from server  
                    this.order = result;
                })
                .catch(error => {
                    // display server exception in toast msg 
                    const event = new ShowToastEvent({
                        title: 'Error',
                        variant: 'error',
                        message: error.body.message,
                    });
                    this.dispatchEvent(event);
                    // reset contacts var with null   
                    this.order = null;
                });
        }
        else {
            // fire toast event if input field is blank
            const event = new ShowToastEvent({
                variant: 'error',
                message: 'Search text missing..',
            });
            this.dispatchEvent(event);
        }
    }
    handleSuccess()
    {
        location.reload();
    }
    on=false;
    
}


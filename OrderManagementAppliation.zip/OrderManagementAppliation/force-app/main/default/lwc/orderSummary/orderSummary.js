import { LightningElement,wire } from 'lwc';
import getData from '@salesforce/apex/orderControl.getalldata';
import submitForApproval from '@salesforce/apex/orderControl.submitForApproval';
import ACCOUNT_OBJECT from '@salesforce/schema/OrderItem';
import { deleteRecord } from 'lightning/uiRecordApi';




export default class OrderSummary extends LightningElement {
    ind
    id
    up
    quan
    ab="modal-content-id-2"
    o
    oid
    a
    x
    y
    or1
    ox
    order
    open
    accountObject = ACCOUNT_OBJECT;
    recordId
    
    @wire (getData)
    getApexData({error,data}){
        if(data){
            this.order=data;
           
            console.log(data);
        }
        if(error)
        {
            console.log('error in fetching data');
        }
        
    }
   
   ed(event){
       this.o=true;
   }
    can(event){
            this.open=false;
        }
        handleSuccess(){
            alert("updated");
            this.open=false;
            location.reload();
        }
    
    edit(event){
        this.x=event.target.name;
     
        alert(this.x);
        this.y=event.target.value;
        alert(this.y);
        
    
        this.open=true;
        this.recordId=this.order[this.x].OrderItems[this.y].Id;
        
        this.id=this.order[this.x].OrderItems[this.y].PricebookEntryId;
       this.up=this.order[this.x].OrderItems[this.y].UnitPrice;
       this.oid=this.order[this.x].OrderItems[this.y].OrderId;
       this.quan=this.order[this.x].OrderItems[this.y].Quantity;
        
    }
    dele(event){
        this.x=event.target.name;
        this.y=event.target.value;
        this.recordId=this.order[this.x].OrderItems[this.y].Id;;
        alert("record id"+this.recordId)
        deleteRecord(this.recordId)
            
            location.reload();
    }
    
    conf(event){
        this.ind=event.target.value;
     //   alert(this.ind);
        this.or1=this.order[this.ind].Id;
      //  alert(this.or1);
        if (window.confirm("Do you want to Confirm Order?")) { 
            submitForApproval({'o':this.or1});
            //alert(this.y);
            //console.log(y)
          // alert("approval sent");// it will submit the form
        }else{
        //do something
        }
       
    }
}